<?php
enum Dia{
    case LUNES;
    case MARTES;
    case MIERCOLES;
    case JUEVES;
    case VIERNES;
}
?>