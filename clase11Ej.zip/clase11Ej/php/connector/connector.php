<?php
class Connector{
    public function getConnection(): PDO{
        // Armado de url

        // MariaDB localhost
        $driver='mysql';
        $hostname='localhost';
        $username='root';
        $password='';
        $base='colegio';
        return new PDO(
                        "$driver:host=$hostname;dbname=$base",
                        $username, 
                        $password
                    );

        // Mysql DB4free
        // $driver='mysql';
        // $hostname='db4free.net';
        // $username='basegeneral';
        // $password='basegeneral';
        // $base='basegeneral';
        // return new PDO(
        //                 "$driver:host=$hostname;dbname=$base",
        //                 $username, 
        //                 $password
        //             );
    
        // $driver='sqlite';
        // $file='../../data/colegio.db';          //test
        // //$file='data/colegio.db';                    //app
        // return new PDO("$driver:$file");

    }

    public function __construct(){} //constructor vacio

    public function get(string $tabla, string $filtro){
        $sql="select * from $tabla where $filtro";
        return $this->getConnection()->query($sql);
    }
    public function geter(string $tabla){
        $sql="select * from $tabla";
        return $this->getConnection()->query($sql);
    }
   

    public function getAll(string $tabla){
        return $this->get($tabla,"1=1");
    }

    public function insert(string $tabla, string $campos, $values){
        $sql="insert into $tabla ($campos) values ($values)";
        return $this->getConnection()->exec($sql);
    }
}

