<?php
include_once "php/connector/connector.php";
$connector = new Connector();
$buscar='';
if(isset($_REQUEST['buscar'])) $buscar=$_REQUEST['buscar'];
$registros = $connector->get("alumnos","apellido like '%".$buscar."%'");
foreach ($registros as $registro) {
    echo ("<tr>");
    echo ("<td>" . $registro['id'] . "</td>");
    echo ("<td>" . $registro['nombre'] . "</td>");
    echo ("<td>" . $registro['apellido'] . "</td>");
    echo ("<td>" . $registro['edad'] . "</td>");
    echo ("<td>" . $registro['id_curso'] . "</td>");
    echo ("</tr>");
}
?>