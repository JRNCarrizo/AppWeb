<?php ini_set("display_errors","1");?>
<?php
    require_once "php/connector/connector.php";
    $connector =new Connector();

    if(
        isset($_REQUEST['nombre']) && $_REQUEST['nombre']!="" &&
        isset($_REQUEST['apellido']) && $_REQUEST['apellido']!=""&&
        isset($_REQUEST['edad']) && $_REQUEST['edad']!="" &&
        isset($_REQUEST['id_curso']) && $_REQUEST['id_curso']!=""
    ){
        $nombre=$_REQUEST['nombre'];
        $apellido=$_REQUEST['apellido'];
        $edad=$_REQUEST['edad'];
        $id_curso=$_REQUEST['id_curso'];
        //echo $nombre.' '.$apellido.' '.$edad.' '.$id_curso;

        $table="alumnos";
        $campos="nombre,apellido,edad,id_curso";
        $values="'".$nombre."','".$apellido."','".$edad."','".$id_curso."'";
        $connector->insert($table,$campos,$values);
        echo "Se guardo un alumno!";
    }else{
        echo 'Ingrese un nuevo alumno!';
    }


?>