<?php
include_once "php/connector/connector.php";

$connector=new Connector();
$registros=$connector->geter(
        "cursos");
foreach($registros as $row){
    echo "<option value='". $row['id'].', '.$row['titulo'].', '.$row['profesor'].', '.
         $row['dia'].', '.$row['turno']."' >". $row['id'].', '.$row['titulo'].', '.$row['profesor'].', '.
         $row['dia'].', '.$row['turno']."</option>";}
    

    ?>