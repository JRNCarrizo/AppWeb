<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de colegio</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>

<body onload="mueveReloj()">

    <div class="container-lg">

        <!-- Menú de navegación -->
        <?php include "menu.php"; ?>

        <!-- Banner -->
        <h1 class="text-center text-primary p-2 m-2 bg-body-tertiary">
            Mantenimiento de alumnos
        </h1>

        <!-- Formulario alumnos -->
        <div>
            <form class="p-3 m-3 bg-body-tertiary" 
                th:action="@{/saveAlumno}" th:object="${alumno}" method="post">

                <!-- Nombre -->
                <div class="mb-3 row bg-secondary-subtle p-2">
                    <label for="nombre" class="col-sm-3 col-form-label text-primary">
                        Nombre
                    </label>
                    <div class="col-sm-9">
                        <input type="text" name="nombre" class="form-control" id="nombre" required minlength="3" maxlength="25">
                    </div>
                </div>

                <!-- Apellido -->
                <div class="mb-3 row bg-secondary-subtle p-2">
                    <label for="apellido" class="col-sm-3 col-form-label text-primary">
                        Apellido
                    </label>
                    <div class="col-sm-9">
                        <input type="text" name="apellido" class="form-control" id="apellido" required minlength="3" maxlength="25">
                    </div>
                </div>

                <!-- Edad -->
                <div class="mb-3 row bg-secondary-subtle p-2">
                    <label for="edad" class="col-sm-3 col-form-label text-primary">
                        Edad
                    </label>
                    <div class="col-sm-9">
                        <input type="number" name="edad" class="form-control" id="edad" 
                                required min="18" max="120">
                    </div>
                </div>

                <!-- Curso -->
                <div class="mb-3 row bg-secondary-subtle p-2">
                    <label for="curso" class="col-sm-3 col-form-label text-primary">
                        Curso
                    </label>
                    <div class="col-sm-9">
                        <select id="id_curso" name="id_curso"  class="form-select" aria-label="Default select example">
                        <?php require_once "php/select_curso.php"; ?>
                        </select>
                    </div>
                </div>

                <!-- Botones -->
                <div class="mb-3 row bg-secondary-subtle p-2">
                    <div class="col-sm-6">
                        <button type="reset" class="btn btn-danger col-sm-6">Borrar</button>
                    </div>
                    <div class="col-sm-6">
                        <button type="submit" class="btn btn-success col-sm-6">Guardar</button>
                    </div>
                </div>

              <!-- Información -->
              <div class="mb-3 row bg-secondary-subtle p-2">
                    <label for="info" class="col-sm-3 col-form-label text-primary">
                        Información
                    </label>
                    <div class="col-sm-9">
                        <div class="form-control text-primary">
                            <?php require_once "php/alumnos_insert.php"; ?>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <!-- Tabla de alummnos -->
        <table class="table table-success table-striped table-hover">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Nombre</th>
                <th scope="col">Apellido</th>
                <th scope="col">Edad</th>
                <th scope="col">Curso</th>
              </tr>
            </thead>
            <tbody>
            <?php require_once "php/alumnos_table.php"; ?> 
            </tbody>
          </table>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
</body>

<script src="js/reloj.js"></script>

</html>